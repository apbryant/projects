﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(TravelTracker.Startup))]
namespace TravelTracker
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
