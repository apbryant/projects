﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TravelTracker.Models
{
    public class CountryList
    {
        public string CountryJSON { get; set; }

    }
}