﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using NPOI.XSSF.UserModel;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;       //Microsoft Excel 14 object in references-> COM tab

namespace TravelTracker.Models
{
    public class Data
    {
        public static Dictionary<string, int> LoadData()
        {
            //Dictionary<string, int> dataDictionary = new Dictionary<string, int>();
            //int lastExcelRow = 1048576;
            //XSSFWorkbook wb = new XSSFWorkbook(@"C:\\Users\AndrewB\Desktop\travel_data_2.xls");
            //XSSFSheet ws = (XSSFSheet)wb.GetSheetAt(0);
            //Dictionary<string, int> dataDictionary = new Dictionary<string, int>();
            //for (int i = 1; i < lastExcelRow; i++)
            //{
            //    XSSFRow row = (XSSFRow)ws.GetRow(i);
            //    if (row == null)
            //    {
            //        break;
            //    }
            //    string country = row.GetCell(0).ToString();
            //    int daysInCountry = (int)row.GetCell(3).NumericCellValue;
            //    dataDictionary.Add(country, daysInCountry);
            //}

            Dictionary<string, int> dataDictionary = new Dictionary<string, int>();
            List<string> countries = new List<string>();
            List<int> daysList = new List<int>();
            using (var reader = new StreamReader(@"C:\\Users\AndrewB\Desktop\travel_data_2.csv"))
            {
                
                string headerLine = reader.ReadLine();
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                  
                    string[] values = line.Split(',');
                    string country = values[0];
                    string days = values[3];

                    countries.Add(country);
                    daysList.Add(Int32.Parse(days));
                }
                
            }
            List<string> distinctCountries = countries.Distinct().ToList();

            foreach (string country in distinctCountries)
            {
                int totalDays = 0;
                for (int i = 0; i < countries.Count(); i++)
                {
                    if (country == countries[i])
                    {
                        totalDays += daysList[i];
                    }
                }
                dataDictionary.Add(country, totalDays);
            }
            //Application xlApp = new Excel.Application();
            //Workbook wb = xlApp.Workbooks.Open("travel_data.xlsx");
            //Worksheet ws = wb.Worksheets.get_Item(1);
            //int rw = ws.Rows.Count;
            //int cl = ws.Columns.Count;
            //Range range = ws.UsedRange;
            
            //for (int i = 0; i < rw; i++)
            //{
            //    dataDictionary.Add(range.Cells[i, 1], range.Cells[i, 4]);
            //}
            return dataDictionary;
        }
    }
}