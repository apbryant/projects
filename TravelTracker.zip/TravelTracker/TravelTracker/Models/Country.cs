﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TravelTracker.Models
{
    public class Country
    {
        public string Name { get; set; }
        public int Days { get; set; }
    }
}