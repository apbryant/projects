﻿using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TravelTracker.Models;

namespace TravelTracker.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            //Dictionary<string, int> dataDictionary = Models.Data.LoadData();
            //List<Country> data = new List<Country>();
            //foreach (KeyValuePair<string, int> item in dataDictionary)
            //{
            //    Country country = new Country();
            //    country.Name = item.Key;
            //    country.Days = item.Value;
            //    data.Add(country);
            //}

            //string json = Newtonsoft.Json.JsonConvert.SerializeObject(data);
         
            
            //CountryList countryJSON = new CountryList();
            //countryJSON.CountryJSON = json;

            // MAKE A JSON FILE WITH THE DATA THAT CAN BE LOADED INTO D3
            
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}