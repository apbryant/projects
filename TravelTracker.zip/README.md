This project shows a map of countries that I have been to and for how long

#Data sources

##Map

For the map of the world I adapted the map used in the Udacity Data Analyst Nanodegree (a course which I completed). The data come from  the world_countries.json file containing a map of the entire world.

##Length of time in a country

To calculate the time I spent in each country, I pulled out my passport and entered the dates I was in each country in an Excel spreadsheet. For trips that happened before I got my current passport (one trip to El Salvador and one trip to Spain), I guess-timated that quantity of time I was in those countries. With some Excel magic I had a list of countries I had visited and how long I was in them. I then used an online json converter to convert the data from a .csv file to a .json file. 

The data were accurate when I started the project, but as time has passed I have spent more time in Chile, so the calculated values will show me being in Chile for less time than I currently have. This, however, doesn't affect the values in the map.

##countries_and_days.json

I took a list of three-letter country codes and put them into Excel, along with the number of days I had spent in each country (for most countries this was zero). I then coverted the file to json using an online converter.